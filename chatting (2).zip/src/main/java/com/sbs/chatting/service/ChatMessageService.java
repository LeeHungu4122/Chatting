package com.sbs.chatting.service;

import java.util.List;
import java.util.Map;

import com.sbs.chatting.dto.ChatMessage;

public interface ChatMessageService {

	public Map<String, Object> add(String writer, String body);

	public List<ChatMessage> getAll();

	public List<ChatMessage> getMessages(int from);

}
