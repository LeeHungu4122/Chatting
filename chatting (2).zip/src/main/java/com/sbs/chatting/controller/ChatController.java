package com.sbs.chatting.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sbs.chatting.dto.ChatMessage;
import com.sbs.chatting.service.ChatMessageService;

@Controller
public class ChatController {
	@Autowired
	ChatMessageService chatMessageService;

	@RequestMapping("/chat/main")
	public String showMain() {
		return "chat/main";
	}

	@RequestMapping("/chat/addMessage")
	@ResponseBody
	public Map addMessage(String writer, String body) {
		Map rs = chatMessageService.add(writer, body);

		return rs;
	}

	@RequestMapping("/chat/getAllMessages")
	@ResponseBody
	public List<ChatMessage> getAllMessages() {
		return chatMessageService.getAll();
	}

	// 자신이 원하는 부분의 채팅부터 가져올 수 있게 하는 부분. 엔터를 누르지 않고도 주기적 실행됨.
	@RequestMapping("/chat/getMessages")
	@ResponseBody
	public List<ChatMessage> getMessages(int from) {
		return chatMessageService.getMessages(from);
	}

	@RequestMapping("/chat/clearMessages")
	@ResponseBody
	public Map clearMessages() {
		// 추후 구현
		Map rs = new HashMap<String, Object>();
		rs.put("msg", "모든 메세지가 삭제되었습니다.");
		rs.put("resultCode", "S-1");

		return rs;
	}
}
