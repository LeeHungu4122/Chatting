package com.sbs.chatting.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.sbs.chatting.dto.ChatMessage;

@Mapper
public interface ChatMessageDao {
	public List<ChatMessage> getList(int from);

	public List<ChatMessage> getAll();

	public void add(Map<String, Object> param);
}
