package com.sbs.chatting.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbs.chatting.dao.ChatMessageDao;
import com.sbs.chatting.dto.ChatMessage;

@Service
public class ChatMessageServiceImpl implements ChatMessageService {
	@Autowired
	ChatMessageDao chatMessageDao;

	public Map<String, Object> add(String writer, String body) {
		Map<String, Object> param = new HashMap<>();
		param.put("writer", writer);
		param.put("body", body);
		chatMessageDao.add(param);

		Map<String, Object> rs = new HashMap<>();
		rs.put("resultCode", "S-1");
		rs.put("msg", "등록되었습니다.");
		rs.put("id", param.get("id"));

		return rs;
	}

	public List<ChatMessage> getAll() {
		return chatMessageDao.getAll();
	}

	public List<ChatMessage> getMessages(int from) {
		return chatMessageDao.getList(from);
	}

}
